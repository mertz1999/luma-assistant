Archive member content for ingestion tests.
